<html lang="en">
<?php
    include 'dbh.php';
?>


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chef's Best Friend</title>
    <link rel="stylesheet" href="style1.css?v=<?php echo time(); ?>">
</head>
